// 1 - white rabbit
const rabbit = {
    color: "white",
    checkWatch() {
        console.log(`A ${this.color} rabbit checks his watch and exclaims, 'I\'m late!'`);
    }
};
rabbit.checkWatch();

// 2 - spaceship
const spaceship = {
    // your code here
    name: "Serenity",
    launch() {
        return(`You have launched the spaceship ${this.name}!`);
    }
};
console.log(spaceship.launch());

// 3 - shopping cart
const cart = {
    // your code here
    contents: [],
    addItem(item) {
        this.contents.push(item);
    },

    // bonus challenge
    removeItem(item) {
        let indexNum = this.contents.indexOf(item)
        if (indexNum > -1) {
            this.contents.splice(indexNum, 1)
            console.log("success")
        } else {
            console.log("That item doesnt exits")
        }
    }
};
cart.addItem("laptop");
cart.addItem("mac")
for (items of cart.contents)
{
    console.log(items)
}

// bonus challenge
cart.removeItem("laptops");

// 4 - lever
// your code here
const lever = {
    stamp: "ACME",
    pull() {
        console.log(`An anvil stamped ${this.stamp} drops on your head.`);
    }
}
lever.pull();