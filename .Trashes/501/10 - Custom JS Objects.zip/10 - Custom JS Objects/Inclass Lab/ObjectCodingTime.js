//Coding Time assignments: https://github.com/bpesquet/thejsway/blob/master/manuscript/chapter06.md
const player1 = {
    name: "Mario",
    health: 150,
    strength: 25,
    xp: 0,
    //add method after the procedural describe(); 
    describe() {
        
       return (
            `${this.name} has ${this.health} health points, ${this.strength} strength and ${this.xp} XP points`
        );


    }
}

player1.health -= 20;
player1.strength =+ 10;
player1.xp += 15;

console.log(player1.describe());

//Modeling a Dog

// TODO: create the dog object here
const dog = {
    name: "Fang",
    species: "boarhoud",
    weight: 75,
    bark() {
        return "Grrr!, Grrr";
    }
}

console.log(`${dog.name} is a ${dog.species} dog measuring ${dog.weight}`);
console.log(`Look, a cat! ${dog.name} barks: ${dog.bark()}`);

/*
Modeling a bank account

Write a program that creates an account object with the following characteristics:

    A name property set to "Alex".
    A balance property set to 0.
    A credit method adding the (positive or negative) value passed as an argument to the account balance.
    A describe method returning the account description.

Use this object to show its description, crediting 250, debiting 80, then show its description again.


*/

const account = {
    name: "Alex",
    balance: 0,
    credit(amt) {
        this.balance += amt;
    },
    describe() {
        return `Account: ${account.name}, Balance ${account.balance}`;
    }
}


account.credit(250);
console.log(account.describe());
account.credit(-80);
console.log(account.describe());

