class Player {
    constructor (name, aHealth, aStrength)
    {
        this.name = name;
        this.health = aHealth;
        this.strength = aStrength

    }

    describe()
    {
        return(
          `${this.name} has ${this.health} health points and ${this.strength} strength`
        );
    }
}

let player1 = new Player("John", 1000, 2000);
let player2 = new Player("Bryan", 1, 10)
// let players = [player1, player2];
let players = [];
players.push(player1)
players.push(player2)
console.log(players);

for (aPlayer of players) {
    console.log(aPlayer.describe());
}
