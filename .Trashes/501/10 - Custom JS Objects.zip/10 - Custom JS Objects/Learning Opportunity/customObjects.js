//Js Objects
//**************************************** */
//any thing you can describe in our real world
//objects are things which have properties (noun) and methods(funcitons)
//**************************************** */


// const pen = {
//   type: "ballpoint",
//   brand: "bic",
//   color: ['blue', 'black','red'],
//   parts: {
//       cap: true,
//       refillable: true
//   }
// };

//***********************access the properties with the dot notation
// console.log(pen.type)
// console.log(pen.brand)
// console.log(`I write with a ${pen.brand} ${pen.type}`);

// ***** accessing the array
// console.log(pen.color)
// console.log(pen.color[0])

// loop through the array
// for (let mypen of pen.color) {
//     console.log(mypen);
// }
// pen.color.forEach((mypen) => {
//     console.log(mypen)
// })



// ***** accessing the object
// console.log(pen.parts)
// console.log(pen.parts.cap);


// pen.price = "2.5";
// console.log(pen)
// console.log(pen.price);


//****************************************************************
//example of an object:  RPG Game Character Aurora
// have class create the aurora object with a name, health and strength

const player1 = {
    name: "Mario",
    health: 150,
    strength: 25,
    //add method after the procedural describe(); 
    // describe() {
    //     console.log(this.name)
    //     //***********demonstrate this
    //     let localVariable = "NoOne";
    //     console.log(localVariable); // no use of this - refers to local variable
    //     //console.log(name) // won't work - not defined

    //    return (
    //         `${this.name} has ${this.health} health points and ${this.strength} strength`
    //     );


    // }
}
// *** lets output the data
console.log(`${player1.name} has ${player1.health} health points and ${player1.strength} strength`)
//** lets play a round of the game */
player1.health += 200
player1.strength -= 10
// ** output the data again - seems like a good place for a function
console.log(`${player1.name} has ${player1.health} health points and ${player1.strength} strength`)


console.log(describe(player1));
function describe(character) {
    return (
        `${character.name} has ${character.health} health points and ${character.strength} strength`
    );
}

// ******** move the describe funciton to the objects as methods
// console.log(player1.describe())

// Let's create 
const player2 = {
    name:"Luigi",
    health: 100,
    strength: 50,
    describe()
    {
        return(
          `${this.name} has ${this.health} health points and ${this.strength} strength`
        );
    }
}

console.log(player2.describe());
player2.health -= 50;
player2.strength += 300;
console.log(player2.describe());


//**** put your objects into arrays */

let players = [];
players.push(player1);
players.push(player2);

console.log(players) //look at this and get comfy with the look and how to read
// *** examine how this works
console.log(players[0]);
console.log(players[0].name)
console.log(players[0].describe());
console.log(players[1]);

for (player of players) {
    console.log(player.describe());
}




