//Js Objects
//**************************************** */
//any thing you can describe in our real world
//objects are things which have properties (noun) and methods(funcitons)
//**************************************** */


const pen = {
  type: "ballpoint",
  brand: "bic",
  color: ['blue', 'black','red'],
  parts: {
      cap: true,
      refillable: true
  }
};

//***********************access the properties with the dot notation
console.log(pen.type)
console.log(pen.brand)
console.log(`I write with a ${pen.brand} ${pen.type}`);

// ***** accessing the array
console.log(pen.color)
console.log(pen.color[0])

// loop through the array with different array methods
// for ... of
//https://www.w3schools.com/js/js_loop_forof.asp
for (let mypen of pen.color) {
    console.log(mypen);
}
// OR the foreach
// https://www.w3schools.com/jsref/jsref_foreach.asp
pen.color.forEach((mypen) => {
    console.log(mypen)
})



// ***** accessing the object
console.log(pen.parts)
console.log(pen.parts.cap);

// *** you can add properties on even after you already defined them
pen.price = "2.5";
console.log(pen)
console.log(pen.price);


//****************************************************************
//example of an object:  RPG Game Character 


const player = {
    name: "Luigi",
    health: 150,
    strength: 25,
    
}
// *** lets output the data
console.log(`${player.name} has ${player.health} health points and ${player.strength} strength`)
//** lets play a round of the game */
player.health += 200
player.strength -= 10
// ** output the data again - seems like a good place for a function
console.log(`${player.name} has ${player.health} health points and ${player.strength} strength`)

// This is called PROCUEDURAL coding, you have a stand alone funciton, and you send it the data that it needs
console.log(describe(player));
function describe(character) {
    return (
        `${character.name} has ${character.health} health points and ${character.strength} strength`
    );
}

// ******** let's move the describe function to the object as a method
// this is OBJECT ORIENTED programming where we access an object and it's properties and methods. 
// How does the program know which method and properties to use? 
// Whatever is in front of the dot
// Remember object.method  or object.property

const player1 = {
    name: "Mario",
    health: 150,
    strength: 25,
    //add the method; 
    describe() {
        // the keyword 'this' represents the object's property
        console.log(this.name)
        
        // no keyword 'this' represents a local variable
        let localVariable = "a local variable";
        console.log(localVariable); // without the 'this' keyword - this refers to localVaraible 

        //console.log(name) // won't work - name is not defined

       return (
            `${this.name} has ${this.health} health points and ${this.strength} strength`
        );


    }
}
// how does the code know which properties to utilize? player1 is an object, so use the values that are stored in player1 properties and methods
console.log(player1.describe())



// Let's create another player object
const player2 = {
    name:"Wario",
    health: 100,
    strength: 50,
    describe()
    {
        return(
          `${this.name} has ${this.health} health points and ${this.strength} strength`
        );
    }
}


console.log(player2.describe());
player2.health -= 50;
player2.strength += 300;
console.log(player2.describe()); // this method belongs to player2 object so it knows only about player2 property and values


//**** lets put these objects into arrays */
let players = [];
players.push(player1);
players.push(player2);

console.log(players) //look at this and get comfy with the look and how to read
// *** examine how this works
console.log(players[0]);
console.log(players[0].name)
console.log(players[0].describe());
console.log(players[1]);

// loop through the player arrays and utilizing each method, outputs the unique values
for (aPlayer of players) {
    console.log(aPlayer.describe());
}




